// Skill aliases
const SKILL_ALIASES = {
    "py": "Python",
    "js": "JavaScript",
    "ml": "Machine Learning",
    "dl": "Deep Learning",
    "sql": "SQL",
    "ds": "Data Science",
    "ai": "Artificial Intelligence",
    "html": "HTML",
    "css": "CSS",
    "rb": "Ruby",
    "cpp": "C++",
    "c#": "C#",
    "java": "Java",
    "flask": "Flask",
    "dj": "Django"
};

// Job roles with required skills
const JOB_ROLES = {
    "Data Analyst": ["Python", "SQL", "Excel", "Data Visualization"],
    "Web Developer": ["HTML", "CSS", "JavaScript", "Python"],
    "Machine Learning Engineer": ["Python", "Machine Learning", "Deep Learning", "SQL"],
    "Software Engineer": ["C++", "Java", "Python", "Algorithms"],
    "AI Engineer": ["Python", "Artificial Intelligence", "Machine Learning", "Deep Learning"],
    "Frontend Developer": ["HTML", "CSS", "JavaScript", "React"],
    "Backend Developer": ["Python", "Flask", "Django", "SQL"],
    "Full Stack Developer": ["HTML", "CSS", "JavaScript", "Python", "SQL"],
    "Database Administrator": ["SQL", "Database Management", "Python"],
    "Cloud Engineer": ["Python", "AWS", "Azure", "DevOps"],
    "Cybersecurity Analyst": ["Networking", "Python", "Security Tools"],
    "Data Scientist": ["Python", "Data Science", "Machine Learning", "Statistics"],
    "Mobile App Developer": ["Java", "Kotlin", "Flutter", "React Native"],
    "DevOps Engineer": ["Python", "Linux", "Docker", "Kubernetes"],
    "Game Developer": ["C++", "Unity", "C#", "3D Modeling"],
    "Business Analyst": ["Excel", "SQL", "Python", "Data Visualization"],
    "UI/UX Designer": ["Figma", "Adobe XD", "Prototyping", "CSS"]
};
