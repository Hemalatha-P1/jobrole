from flask import Flask, render_template, request, redirect, url_for, session

app = Flask(__name__)
app.secret_key = "secret123"

# Hardcoded users (username: password)
USERS = {
    "Dhanya": "1234",
    "student": "pass",
    "admin": "admin123"
}

@app.route("/", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form["username"]
        password = request.form["password"]

        if username in USERS and USERS[username] == password:
            session["username"] = username
            return redirect(url_for("details"))
        else:
            return render_template("login.html", error="Invalid credentials")
    return render_template("login.html")

@app.route("/details", methods=["GET", "POST"])
def details():
    if "username" not in session:
        return redirect(url_for("login"))

    if request.method == "POST":
        name = request.form["name"]
        dept = request.form["dept"]
        skills = request.form["skills"]

        session["name"] = name
        session["dept"] = dept
        session["skills"] = skills
        return redirect(url_for("roles"))

    return render_template("details.html", username=session["username"])

@app.route("/roles", methods=["GET", "POST"])
def roles():
    if "skills" not in session:
        return redirect(url_for("details"))

    return render_template("roles.html",
                           name=session["name"],
                           dept=session["dept"],
                           skills=session["skills"])

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
